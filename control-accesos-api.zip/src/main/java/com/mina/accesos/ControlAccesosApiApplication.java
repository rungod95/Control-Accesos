package com.mina.accesos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ControlAccesosApiApplication {
    public static void main(String[] args) {
        SpringApplication.run(ControlAccesosApiApplication.class, args);
    }
}
